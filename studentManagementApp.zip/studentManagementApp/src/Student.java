import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    
    private String studentId;
    private String studentName;
    private int studentAge;
    private String studentEmail;
    private String studentCourse;
 
    private String id;
    private String name;
    private int age;
    private String email;
    private String course;
    
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

   
    private static ArrayList<Student> studentList = new ArrayList<>();

    
    public Student(String studentId, String studentName, int studentAge, String studentEmail, String studentCourse) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentEmail = studentEmail;
        this.studentCourse = studentCourse;
    }

   
    public String getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    
    public static void SaveStudent(Student student) {
        studentList.add(student);
        System.out.println("Student details have been successfully saved.");
    }

 
    public static void SearchStudent(String studentId) {
        for (Student student : studentList) {
            if (student.getStudentId().equals(studentId)) {
                System.out.println("\nSTUDENT FOUND");
                System.out.println("*******************************");
                student.displayStudentInfo();
                return;
            }
        }
        System.out.println("Student with ID " + studentId + " cannot be located.");
    }


    public static void DeleteStudent(String studentId) {
        for (int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).getStudentId().equals(studentId)) {
                System.out.print("Are you sure you want to delete this student? (yes/no): ");
                Scanner scanner = new Scanner(System.in);
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("yes")) {
                    studentList.remove(i);
                    System.out.println("Student with ID " + studentId + " has been successfully deleted.");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                return;
            }
        }
        System.out.println("Student with ID " + studentId + " cannot be located.");
    }

  
    public static void StudentReport() {
        if (studentList.isEmpty()) {
            System.out.println("No students registered yet.");
        } else {
            System.out.println("\nSTUDENT REPORT");
            System.out.println("****************************************************************");
            System.out.println(String.format("%-10s %-20s %-10s %-30s %-15s", 
                                              "ID", "Name", "Age", "Email", "Course"));
            System.out.println("****************************************************************");
            for (Student student : studentList) {
                System.out.println(String.format("%-10s %-20s %-10d %-30s %-15s", 
                                                  student.getStudentId(), 
                                                  student.getStudentName(), 
                                                  student.getStudentAge(), 
                                                  student.getStudentEmail(), 
                                                  student.getStudentCourse()));
            }
            System.out.println("****************************************************************");
        }
    }

 
    public static void ExitStudentApplication() {
        System.out.println("Exiting the application...");
        System.exit(0);
    }


    public void displayStudentInfo() {
        System.out.println("ID: " + studentId);
        System.out.println("Name: " + studentName);
        System.out.println("Age: " + studentAge);
        System.out.println("Email: " + studentEmail);
        System.out.println("Course: " + studentCourse);
    }

}

import java.util.Scanner;

public class StudentManagementApp {
   static String input = "";
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display the start screen
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*******************************");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        
         input = scanner.nextLine();
        
        if (input.equals("1")) {
            launchMenu(scanner);
        } else {
            Student.ExitStudentApplication();
        }
        
        scanner.close();
    }
    
    
    public static void launchMenu(Scanner scanner) {
        while (true) {
            System.out.println("\nMENU");
            System.out.println("1. Register a new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Delete a student");
            System.out.println("4. Display all students");
            System.out.println("5. View student report");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");
            String option = scanner.nextLine();
            
            switch (option) {
                case "1":
                    captureNewStudent(scanner);
                    break;
                case "2":
                    System.out.print("Enter the student ID to search: ");
                    String searchId = scanner.nextLine();
                    Student.SearchStudent(searchId);
                    input = scanner.nextLine();
                    break;
                case "3":
                    System.out.print("Enter the student ID to delete: ");
                    String deleteId = scanner.nextLine();
                    Student.DeleteStudent(deleteId);
                    break;
                case "4":
                    Student.StudentReport();
                   System.out.print("Enter (1) to launch menu or any other key to exit: ");
                   input = scanner.nextLine();
                    break;
                case "5":
                    Student.StudentReport();
                    System.out.print("Enter (1) to launch menu or any other key to exit: ");
                   input = scanner.nextLine();
                    break;
                case "6":
                    Student.ExitStudentApplication();
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    
    public static void captureNewStudent(Scanner scanner) {
        System.out.println("\nCAPTURE A NEW STUDENT");
        System.out.println("*******************************");
        
        System.out.print("Enter the student id: ");
        String studentId = scanner.nextLine();
        
        System.out.print("Enter the student name: ");
        String studentName = scanner.nextLine();
        
        int studentAge = 0;
        while (true) {
            try {
                System.out.print("Enter the student age: ");
                studentAge = Integer.parseInt(scanner.nextLine());
                if (studentAge >= 16) {
                    break;
                } else {
                    System.out.println("You have entered an incorrect student age!!! The age must be 16 or older.");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect student age!!! Please enter a valid number.");
            }
        }
        
        System.out.print("Enter the student email: ");
        String studentEmail = scanner.nextLine();
        
        System.out.print("Enter the student course: ");
        String studentCourse = scanner.nextLine();
        
        
        Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        Student.SaveStudent(student);
        
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        String input = scanner.nextLine();
        
        if (!input.equals("1")) {
            Student.ExitStudentApplication();
        }
    }
}

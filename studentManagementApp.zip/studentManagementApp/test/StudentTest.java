import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StudentTest {
    private StudentManagement sm;

    @Before
    public void setUp() {
        sm = new StudentManagement();
    }

    @Test
    public void TestSaveStudent() {
        boolean isSaved = sm.SaveStudent("10111", "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        assertTrue(isSaved);

        Student student = sm.SearchStudent("10111");
        assertNotNull(student);
        assertEquals("J.Bloggs", student.getName());
        assertEquals(19, student.getAge());
        assertEquals("jbloggs@ymail.com", student.getEmail());
        assertEquals("disd", student.getCourse());
    }

    @Test
    public void testSearchStudent() {
        sm.SaveStudent("10111", "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        Student student = sm.SearchStudent("10111");

        assertNotNull(student);
        assertEquals("J.Bloggs", student.getName());
        assertEquals(19, student.getAge());
        assertEquals("jbloggs@ymail.com", student.getEmail());
        assertEquals("disd", student.getCourse());
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        Student student = sm.SearchStudent("99999");
        assertNull(student);
    }

    @Test
    public void testDeleteStudent() {
        sm.SaveStudent("10111", "J.Bloggs", 19, "jbloggs@ymail.com", "disd");
        boolean isDeleted = sm.DeleteStudent("10111");
        assertTrue(isDeleted);

        Student student = sm.SearchStudent("10111");
        assertNull(student);
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        boolean isDeleted = sm.DeleteStudent("99999");
        assertFalse(isDeleted);
    }

    @Test
    public void testStudentAge_StudentAgeValid() {
        boolean isSaved = sm.SaveStudent("10112", "A.Nother", 18, "another@example.com", "software dev");
        assertTrue(isSaved);

        Student student = sm.SearchStudent("10112");
        assertNotNull(student);
        assertEquals(18, student.getAge());
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        boolean isSaved = sm.SaveStudent("10113", "B.Others", 15, "bothers@example.com", "info management");
        assertFalse(isSaved);  // Assuming the SaveStudent method handles validation
    }

    @Test(expected = NumberFormatException.class)
    public void testStudentAge_StudentAgeInvalidCharacter() {
        sm.SaveStudent("10114", "C.Smith", Integer.parseInt("Invalid"), "csmith@example.com", "mobile dev");
    }
}
